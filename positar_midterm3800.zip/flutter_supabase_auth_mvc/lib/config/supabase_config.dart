import 'package:supabase_flutter/supabase_flutter.dart';

/// Central configuration for the Supabase backend.
///
/// Replace the placeholder values below with the URL and anon key of
/// your own Supabase project (Supabase Dashboard -> Project Settings -> API).
class SupabaseConfig {
  // TODO: Replace with your Supabase project URL.
  static const String supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';

  // TODO: Replace with your Supabase project anon (public) key.
  static const String supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';

  /// Initializes Supabase. Must be called once in main() before runApp().
  static Future<void> initialize() async {
    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: supabaseAnonKey,
    );
  }
}
