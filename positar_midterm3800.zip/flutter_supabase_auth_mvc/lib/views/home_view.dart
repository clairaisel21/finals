import 'package:flutter/material.dart';

import '../controllers/auth_controller.dart';
import '../models/user_model.dart';
import 'login_view.dart';

// ============================================================
// HOME UI
// ============================================================
// UI provided by instructor. The logout buttons were connected to
// the AuthController and the static placeholder texts now display
// the authenticated user's real information.
// ============================================================
class HomeView extends StatelessWidget {
  final UserModel user;

  const HomeView({super.key, required this.user});

  Future<void> _handleLogout(BuildContext context) async {
    final result = await AuthController.logout();
    if (!context.mounted) return;

    if (result.success) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginView()),
        (route) => false,
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.message ?? 'Logout failed.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            onPressed: () => _handleLogout(context),
            icon: const Icon(Icons.logout),
            tooltip: 'Logout',
          ),
        ],
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const CircleAvatar(
                radius: 50,
                child: Icon(
                  Icons.person,
                  size: 50,
                ),
              ),

              const SizedBox(height: 24),

              const Text(
                'Welcome!',
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 12),

              // Authenticated user's name (falls back to a generic label).
              Text(
                (user.fullName == null || user.fullName!.isEmpty)
                    ? 'Authenticated User'
                    : user.fullName!,
                style: const TextStyle(
                  fontSize: 18,
                ),
              ),

              const SizedBox(height: 8),

              // Authenticated user's email.
              Text(
                user.email,
                style: const TextStyle(
                  color: Colors.grey,
                ),
              ),

              const SizedBox(height: 40),

              SizedBox(
                width: 200,
                height: 48,
                child: OutlinedButton.icon(
                  onPressed: () => _handleLogout(context),
                  icon: const Icon(Icons.logout),
                  label: const Text('Logout'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
