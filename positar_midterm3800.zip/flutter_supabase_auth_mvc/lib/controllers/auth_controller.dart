import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/user_model.dart';

/// Result wrapper for every authentication operation.
class AuthResult {
  final bool success;
  final String? message;
  final UserModel? user;

  const AuthResult({required this.success, this.message, this.user});

  factory AuthResult.successful(UserModel user, [String? message]) =>
      AuthResult(success: true, message: message, user: user);

  factory AuthResult.failure(String message) =>
      AuthResult(success: false, message: message);
}

/// CONTROLLER layer
///
/// Encapsulates all authentication logic and the communication with
/// Supabase. Views never call Supabase directly; they delegate here.
class AuthController {
  static final SupabaseClient _client = Supabase.instance.client;

  /// Registers a new user with Supabase Auth and persists the profile row.
  static Future<AuthResult> register({
    required String fullName,
    required String email,
    required String password,
    String? confirmPassword,
  }) async {
    // Client-side validation before any network call.
    if (fullName.trim().isEmpty) {
      return const AuthResult.failure('Please enter your full name.');
    }
    if (!_isValidEmail(email.trim())) {
      return const AuthResult.failure('Please enter a valid email address.');
    }
    if (password.length < 6) {
      return const AuthResult.failure(
          'Password must be at least 6 characters long.');
    }
    if (confirmPassword != null && password != confirmPassword) {
      return const AuthResult.failure('Passwords do not match.');
    }

    try {
      final response = await _client.auth.signUp(
        email: email.trim(),
        password: password,
        data: {'full_name': fullName.trim()},
      );

      final user = response.user;
      if (user == null) {
        return const AuthResult.failure(
            'Registration failed. Please try again.');
      }

      // The database trigger (handle_new_user) normally creates the
      // profiles row automatically. We upsert defensively so the profile
      // still exists if the trigger was not created or was modified.
      try {
        await _client.from('profiles').upsert({
          'id': user.id,
          'full_name': fullName.trim(),
          'email': email.trim(),
        });
      } catch (_) {
        // Not fatal: the trigger or RLS may already have handled it.
      }

      if (response.session != null) {
        // Email confirmation disabled: user is signed in immediately.
        return AuthResult.successful(
          UserModel.fromSupabaseUser(user, fullName: fullName.trim()),
          'Registration successful!',
        );
      }

      // Email confirmation enabled: a confirmation mail was sent.
      return const AuthResult.failure(
          'Registration successful! Please check your email to confirm '
          'your account before logging in.');
    } on AuthException catch (e) {
      final msg = e.message.toLowerCase();
      if (msg.contains('already registered') ||
          msg.contains('user already exists') ||
          msg.contains('email address') && msg.contains('invalid')) {
        return AuthResult.failure(e.message);
      }
      if (msg.contains('password')) {
        return AuthResult.failure(e.message);
      }
      return AuthResult.failure(
          'Registration failed: ${e.message}');
    } catch (e) {
      return AuthResult.failure(
          'An unexpected error occurred during registration. '
          'Please check your internet connection and try again.');
    }
  }

  /// Signs an existing user in.
  static Future<AuthResult> login({
    required String email,
    required String password,
  }) async {
    if (email.trim().isEmpty || password.isEmpty) {
      return const AuthResult.failure(
          'Please enter both email and password.');
    }
    if (!_isValidEmail(email.trim())) {
      return const AuthResult.failure('Please enter a valid email address.');
    }

    try {
      final response = await _client.auth
          .signInWithPassword(email: email.trim(), password: password);
      final user = response.user;
      if (user == null) {
        return const AuthResult.failure(
            'Login failed. Invalid email or password.');
      }
      return AuthResult.successful(await _loadProfile(user), 'Login successful!');
    } on AuthException catch (e) {
      final msg = e.message.toLowerCase();
      if (msg.contains('invalid login credentials')) {
        return const AuthResult.failure(
            'Invalid email or password. Please try again.');
      }
      if (msg.contains('email not confirmed')) {
        return const AuthResult.failure(
            'Your email is not yet confirmed. Please check your inbox.');
      }
      return AuthResult.failure('Login failed: ${e.message}');
    } catch (e) {
      return const AuthResult.failure(
          'An unexpected error occurred during login. '
          'Please check your internet connection and try again.');
    }
  }

  /// Ends the current session.
  static Future<AuthResult> logout() async {
    try {
      await _client.auth.signOut();
      return const AuthResult.successful(null, 'Logged out successfully.');
    } on AuthException catch (e) {
      return AuthResult.failure('Logout failed: ${e.message}');
    } catch (e) {
      return const AuthResult.failure(
          'An unexpected error occurred during logout.');
    }
  }

  /// Returns the currently signed-in user, or null when not authenticated.
  static Future<UserModel?> getCurrentUser() async {
    try {
      final user = _client.auth.currentUser;
      if (user == null) return null;
      return await _loadProfile(user);
    } catch (_) {
      return null;
    }
  }

  /// True while a session exists, including when the app is reopened.
  static bool get isAuthenticated =>
      _client.auth.currentSession != null;

  /// Streams auth state changes (login, logout, token refresh, session
  /// restore). Views/controllers can listen to react immediately.
  static Stream<AuthState> get authStateChanges =>
      _client.auth.onAuthStateChange;

  // ---------- internal helpers ----------

  static Future<UserModel> _loadProfile(User user) async {
    String? fullName;
    try {
      final row = await _client
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .maybeSingle();
      fullName = row?['full_name'] as String?;
    } catch (_) {
      // Fall back to metadata if the profiles row is missing or blocked.
    }
    return UserModel.fromSupabaseUser(user, fullName: fullName);
  }

  static bool _isValidEmail(String email) {
    final regex = RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$');
    return regex.hasMatch(email);
  }
}
