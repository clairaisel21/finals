/// MODEL layer
///
/// Represents an authenticated application user. All fields are plain data;
/// this class contains no Supabase or Flutter widget code so it can be tested
/// and reused independently of the authentication controller.
class UserModel {
  final String id;
  final String email;
  final String? fullName;
  final DateTime? createdAt;

  const UserModel({
    required this.id,
    required this.email,
    this.fullName,
    this.createdAt,
  });

  factory UserModel.fromSupabaseUser(User user, {String? fullName}) {
    final metaName =
        user.userMetadata?['full_name'] ?? user.userMetadata?['name'];
    return UserModel(
      id: user.id,
      email: user.email ?? '',
      fullName: fullName ?? (metaName is String ? metaName : null),
      createdAt: user.createdAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'email': email,
        'full_name': fullName,
        'created_at': createdAt?.toIso8601String(),
      };

  @override
  String toString() => 'UserModel(id: $id, email: $email, fullName: $fullName)';
}
