# Flutter Supabase Authentication (MVC)

A Flutter application implementing **user registration and login authentication**
using **Supabase**, organized according to the **MVC (Model-View-Controller)**
architecture.

## Project Structure (MVC)

```
lib/
├── main.dart                       # App entry point + auth state checking (splash gate)
├── config/
│   └── supabase_config.dart        # Supabase configuration (MODEL-agnostic setup)
├── models/
│   └── user_model.dart             # MODEL: user data structure
├── controllers/
│   └── auth_controller.dart        # CONTROLLER: registration, login, logout, state
└── views/
    ├── login_view.dart             # VIEW: login screen (provided UI)
    ├── register_view.dart          # VIEW: registration screen (provided UI)
    └── home_view.dart              # VIEW: dashboard (provided UI)
database/
└── schema.sql                      # Provided Supabase SQL script
```

## Setup

### 1. Supabase project
1. Create a project at https://supabase.com (or use the provided project).
2. Open **SQL Editor** in the Supabase dashboard, paste the contents of
   `database/schema.sql`, and run it. This creates the `profiles` table with
   Row Level Security and the `handle_new_user` trigger.
3. Go to **Project Settings -> API** and copy the **Project URL** and the
   **anon public key**.

### 2. Configure the app
Edit `lib/config/supabase_config.dart`:

```dart
static const String supabaseUrl = 'https://YOUR_PROJECT_ID.supabase.co';
static const String supabaseAnonKey = 'YOUR_SUPABASE_ANON_KEY';
```

### 3. Run
```bash
flutter pub get
flutter run
```

## Implementation Notes

- **Supabase authentication only.** No local or hardcoded authentication is
  used. `supabase_flutter` handles sessions, token persistence, and automatic
  session restoration.
- **MVC separation.** Views never call Supabase directly; they delegate every
  operation to `AuthController`, which returns an `AuthResult` (success flag +
  human-readable message + optional `UserModel`). The `UserModel` converts
  Supabase's `User` into a plain Dart data class.
- **Provided UI preserved.** The instructor's layouts, texts, and controllers
  are unchanged. Only the `onPressed` TODO callbacks were implemented, a
  loading spinner was added while a request is in flight, and the home screen's
  placeholder texts now display the authenticated user's real name and email.
- **Error handling.** Client-side validation (empty fields, email format,
  password length, password confirmation) plus mapped `AuthException` messages
  (email already registered, invalid credentials, unconfirmed email, network
  errors) surface as SnackBars.
- **Authentication state checking.** On startup, `main.dart` shows a splash
  gate that queries the current session via `AuthController.getCurrentUser()`
  and routes to `HomeView` (already authenticated) or `LoginView`.
  `AuthController.authStateChanges` also exposes the Supabase auth state
  stream for any listener that needs it.
- **Profiles table.** After registration, the `handle_new_user` trigger
  creates the profile row. The controller additionally performs a defensive
  upsert so the profile exists even if the trigger is absent or modified.
- **Email confirmation.** If email confirmation is enabled in the Supabase
  dashboard, registration reports that a confirmation email was sent. Disable
  it (Auth -> Providers -> Email) if you want users signed in immediately.

## Test Scenarios

| Scenario | Steps | Expected Result |
|---|---|---|
| Successful registration | Register with a new email, valid name, 6+ char password, matching confirmation | Green flow to login screen, success SnackBar, profile row visible in Supabase `profiles` table |
| Failed registration | Register with an existing email, or mismatched passwords, or short password | Red SnackBar with the specific reason; no account created |
| Successful login | Login with registered email and correct password | Redirect to Dashboard showing the user's name and email |
| Invalid login credentials | Login with a wrong password or unregistered email | "Invalid email or password" SnackBar; user stays on login screen |
| Logout | Tap the app bar logout icon or the Logout button on the dashboard | Return to login screen; session cleared |
| Returning while authenticated | Close the app completely, reopen it | Splash gate detects the persisted session and opens the Dashboard directly |
